export type requestDataType = {
    url: string;
    credentials?: any;
    token?: string;
  };