const Navbar = () => {
  return (
    <header>
      <nav>Navbar</nav>
    </header>
  );
};
export default Navbar;
